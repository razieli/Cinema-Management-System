package il.ac.haifa.cs.sweng.cms.common.messages;

/**
 * Abstract class for representing request messages.
 *
 * @author Yuval Razieli
 */
public abstract class AbstractRequest extends AbstractMessage {

}
