package il.ac.haifa.cs.sweng.cms.common.messages;

import java.io.Serializable;

/**
 * Abstract class for representing messages.
 *
 * @author Yuval Razieli
 */
public abstract class AbstractMessage implements Serializable {

}
