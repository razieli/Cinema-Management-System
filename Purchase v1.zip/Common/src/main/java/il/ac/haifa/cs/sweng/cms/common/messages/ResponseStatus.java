package il.ac.haifa.cs.sweng.cms.common.messages;

/**
 * Statuses of responses.
 *
 * @author Yuval Razieli
 */
public enum ResponseStatus {
    Acknowledged,
    Declined
}
