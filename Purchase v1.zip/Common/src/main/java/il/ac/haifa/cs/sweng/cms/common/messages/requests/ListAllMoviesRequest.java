package il.ac.haifa.cs.sweng.cms.common.messages.requests;

import il.ac.haifa.cs.sweng.cms.common.messages.AbstractRequest;

public class ListAllMoviesRequest extends AbstractRequest {

    public ListAllMoviesRequest() { }

}
